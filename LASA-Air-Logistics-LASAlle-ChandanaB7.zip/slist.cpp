#include "slist.h"
#include <assert.h>
#include <iostream>

using namespace std;

linked_list :: linked_list () {
		head = NULL;
		tail = NULL;
		length = 0;
	}

linked_list :: ~linked_list () {
	node* current = head;
	while (current != NULL) {
		node* temp = current;
		current = current->next;
		delete temp;
	}
	length = 0;
}

void linked_list :: add(Airport* val) {
	node* temp = new node;
	temp->data = val;
	temp->next = NULL;

	if (head == NULL) {
		head = temp;
		tail = temp;
	}
	else {
		tail->next = temp;
		tail = tail->next;
	}
	length++;
}

void linked_list :: clear() {
	node*temp = head;
	head = head->next;
	delete(temp);
	length = 0;
}

Airport* linked_list :: get(int index) {
	node*current = head;
	for (int i = 0; i <= index; i++) {
		current = current->next;
	}
	return current->data;
}

int linked_list :: size() {
	return length;
}

bool linked_list :: equals(linked_list list) {
	bool temp = true;
	for (int i = 0; i < length; i++) {
		if (get(i)->code != list.get(i)->code || get(i)->longitude != list.get(i)->longitude || get(i)->latitude != list.get(i)->latitude) {
			temp = false;
		}
	}
	return temp;
}

void linked_list :: insert (int index, Airport* val) {
	node* temp = new node;
	temp->data = val;
	temp->next = NULL;
	node*current = head;
	node*previous = current;
	int count = 0;
	while (current != NULL && count != index) {
		previous = current;
		current = current->next;
		count++;
	}
	temp->next = current;
	previous->next = temp;
	length++;
}

void linked_list :: exchg (int index1, int index2) {
	node*current1 = head;
	int count1 = 0;
	while (current1 != NULL && count1 != index1) {
		current1 = current1->next;
		count1++;
	} 
	node*current2 = head;
	int count2 = 0;
	while (current2 != NULL && count2 != index2) {
		current2 = current2->next;
		count2++;
	} 
	node*temp = current1;
	current1->data = current2->data;
	current2->data = temp->data;
}

void linked_list :: swap (int index1, int index2) {
	node*current1 = head;
	int count1 = 0;
	while (current1 != NULL && count1 != index1) {
		current1 = current1->next;
		count1++;
	} 
	node*current2 = head;
	int count2 = 0;
	while (current2 != NULL && count2 != index2) {
		current2 = current2->next;
		count2++;
	} 
	node*temp = current1;
	current1->next = current2->next;
	current2->next = temp->next;
}

bool linked_list :: isEmpty() {
	return length == 0;
}

void linked_list :: remove(int index) {
	node*current = head;
	node*previous = current;
	int count = 0;
	while (current != NULL && count != index) {
		previous = current;
		current = current->next;
		count++;
	}
	if (current != NULL) {
		if (current == head) {
			head = current->next;
		}
		else if (current != head) {
			previous->next = current->next;
		}
	}
	delete(current);
	length--;
}

void linked_list :: set (int index, Airport* val) {
	node* temp = new node;
	temp->data = val;
	temp->next = NULL;
	node*current = head;
	for (int i = 0; i < index; i++) {
		current = current->next;
	}
	current = temp;
}

// Constructor

// Destructor

// add(value)				//Adds a new value to the end of this list.

// clear()					//Removes all elements from this list.

// equals(list)				//Returns true if the two lists contain the same elements in the same order.

//get(index)				//Returns the element at the specified index in this list.

//insert(index, value)		//Inserts the element into this list before the specified index.

//exchg(index1, index2)		//Switches the payload data of specified indexex.

//swap(index1,index2)		//Swaps node located at index1 with node at index2

// isEmpty()				//Returns true if this list contains no elements.

// remove(index)			//Removes the element at the specified index from this list.

// set(index, value)		//Replaces the element at the specified index in this list with a new value.

// size()					//Returns the number of elements in this list.

// DO NOT IMPLEMENT >>> subList(start, length)	//Returns a new list containing elements from a sub-range of this list.

// DO NOT IMPLEMENT >>> toString()				//Converts the list to a printable string representation.